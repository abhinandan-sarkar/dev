// DOM Elements
const mainSlider = document.getElementById("mainSlider");
const sliderTrack = document.getElementById("sliderContainer");
let slideItems = document.getElementsByClassName("slide");
const indicatorWrapper = document.getElementById("indicatorHolder");

// Configuration
const totalSlides = slideItems.length;
const slideWidth = 1000;
const slideGap = 4;
const slideDelay = 5000;
const transitionSpeed = 1200;

// State Variables
let currentIndex = 1;
let currentDotIndex = 1;
let prevIndex = 0;
let upcomingIndex = 2;

// Display Constants
const SHOW = "inline-flex";
const HIDE = "none";

// Duplicate First Slide
const originalSlidesHTML = sliderTrack.innerHTML;
const firstSlideContent = slideItems[0].innerHTML;
const duplicatedSlideHTML = `<div class="slide" id="slide${slideItems.length + 1}">${firstSlideContent}</div>`;
sliderTrack.innerHTML = originalSlidesHTML + duplicatedSlideHTML;

// Create Indicators
let dotsHTML = "";
for (let i = 0; i < totalSlides; i++) {
  dotsHTML += `<div class="indicators" onclick="goToSlide(${i})"></div>`;
}
indicatorWrapper.innerHTML = dotsHTML;

// Set Active Dot
const dots = document.getElementsByClassName("indicators");
dots[0].classList.add("activeSlide");

// Update Slide List & Track Width
const allSlides = document.getElementsByClassName("slide");
sliderTrack.style.width = (slideWidth * allSlides.length + slideGap * (allSlides.length - 1)) + "px";

// Smooth Transition for Indicators
for (let i = 0; i < dots.length; i++) {
  dots[i].style.transition = (transitionSpeed / 1000) + "s";
}

// Hide All Slides Initially
for (let i = 0; i < slideItems.length; i++) {
  slideItems[i].style.display = HIDE;
}

// Show Initial Two Slides
slideItems[0].style.display = SHOW;
slideItems[1].style.display = SHOW;

// Autoplay Timers
let slideTimer = setInterval(slideAutoTransition, slideDelay);
let indicatorTimer = setInterval(updateDots, slideDelay);
let animationFix;

// Manual Slide Navigation
function goToSlide(index) {
  sliderTrack.style.transition = transitionSpeed + "ms";
  clearInterval(slideTimer);
  clearInterval(indicatorTimer);
  clearTimeout(animationFix);

  if (prevIndex === index) {
    slideItems[index + 1].style.display = SHOW;
    return;
  }

  if (index > prevIndex) {
    // Forward
    for (let i = 0; i < slideItems.length; i++) {
      slideItems[i].style.display = HIDE;
    }
    slideItems[index].style.display = SHOW;
    slideItems[prevIndex].style.display = SHOW;

    for (let i = 0; i < dots.length; i++) {
      dots[i].classList.remove("activeSlide");
    }
    dots[index].classList.add("activeSlide");

    sliderTrack.style.transform = `translateX(-${slideWidth + slideGap}px)`;
    currentDotIndex = index + 1;

    setTimeout(() => {
      sliderTrack.style.transition = "0s";
      sliderTrack.style.transform = "translateX(0px)";
      slideItems[prevIndex].style.display = HIDE;
      slideItems[index - 1].style.display = HIDE;
      slideItems[index + 1].style.display = SHOW;
      prevIndex = index;
      upcomingIndex = (index === slideItems.length - 1) ? 0 : index + 2;
    }, transitionSpeed);
  } else {
    // Backward
    for (let i = 0; i < dots.length; i++) {
      for (let j = 0; j < slideItems.length; j++) {
        slideItems[j].style.display = HIDE;
      }
      slideItems[prevIndex + 1].style.display = SHOW;
      slideItems[prevIndex].style.display = SHOW;
      dots[i].classList.remove("activeSlide");
    }
    dots[index].classList.add("activeSlide");

    const cloned = allSlides[index].outerHTML;
    allSlides[prevIndex + 1].outerHTML = cloned;
    allSlides[prevIndex + 1].style.display = SHOW;

    sliderTrack.style.transform = `translateX(-${slideWidth + slideGap}px)`;
    currentDotIndex = index + 1;

    setTimeout(() => {
      sliderTrack.innerHTML = originalSlidesHTML + duplicatedSlideHTML;
      for (let i = 0; i < slideItems.length; i++) {
        slideItems[i].style.display = HIDE;
      }
      slideItems[index].style.display = SHOW;
      slideItems[prevIndex].style.display = SHOW;
      sliderTrack.style.transition = "0s";
      sliderTrack.style.transform = "translateX(0px)";
      prevIndex = index;
      upcomingIndex = (index === slideItems.length - 1) ? 0 : index + 2;
    }, transitionSpeed);
  }
}

// Autoplay Slide Animation
function slideAutoTransition() {
  sliderTrack.style.transition = transitionSpeed + "ms";
  sliderTrack.style.transform = `translateX(-${slideWidth + slideGap}px)`;

  animationFix = setTimeout(() => {
    if (upcomingIndex === allSlides.length) {
      upcomingIndex = 0;
      sliderTrack.style.transition = "0s";
      sliderTrack.style.transform = "translateX(0px)";
      slideItems[prevIndex].style.display = HIDE;
      prevIndex = 0;
      slideItems[upcomingIndex].style.display = SHOW;
      slideItems[totalSlides].style.display = HIDE;
      upcomingIndex++;
      slideItems[upcomingIndex++].style.display = SHOW;
    } else {
      sliderTrack.style.transition = "0s";
      sliderTrack.style.transform = "translateX(0px)";
      slideItems[prevIndex].style.display = HIDE;
      prevIndex++;
      slideItems[upcomingIndex].style.display = SHOW;
      upcomingIndex++;
    }
  }, transitionSpeed);
}

// Indicator Update
function updateDots() {
  for (let i = 0; i < dots.length; i++) {
    dots[i].classList.remove("activeSlide");
  }
  if (currentDotIndex === totalSlides) currentDotIndex = 0;
  dots[currentDotIndex].classList.add("activeSlide");
  currentDotIndex++;
}

// Hover Pause/Resume
mainSlider.addEventListener("mouseenter", () => {
  clearInterval(slideTimer);
  clearInterval(indicatorTimer);
});
mainSlider.addEventListener("mouseleave", () => {
  slideTimer = setInterval(slideAutoTransition, slideDelay);
  indicatorTimer = setInterval(updateDots, slideDelay);
});
