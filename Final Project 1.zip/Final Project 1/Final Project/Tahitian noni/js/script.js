/* For Banner Part - Stable, Smooth Blink */

let bannerImg = document.querySelectorAll('.box img');
let activeIndex = 0;
let intervalTimer = 4000;
let blinkInterval;

// Initialize: remove all blink classes, set first
bannerImg.forEach(img => img.classList.remove('blink'));
bannerImg[activeIndex].classList.add('blink');

// Function to switch blink image
function blinkFn() {
  bannerImg[activeIndex].classList.remove('blink');
  activeIndex = (activeIndex + 1) % bannerImg.length;
  bannerImg[activeIndex].classList.add('blink');
}

// Start blinking
blinkInterval = setInterval(blinkFn, intervalTimer);

// Pause/resume on hover
let bannerBox = document.querySelector('.box');
bannerBox.addEventListener('mouseenter', () => {
  clearInterval(blinkInterval);
  console.log('Blink paused on hover');
});

bannerBox.addEventListener('mouseleave', () => {
  blinkInterval = setInterval(blinkFn, intervalTimer);
  console.log('Blink resumed on mouse leave');
});


/* For Accordion Part */
let accHtml = document.querySelectorAll('.accordion-text');
let lodersImg = document.querySelectorAll('.loader img');
let loders = document.querySelectorAll('.loader');
let fixedHeight = 120;

// Initialize accordion
accHtml.forEach((ele, val) => {
  if (val === 0) {
    ele.style.height = fixedHeight + 'px';
    lodersImg[val].classList.add('rotate-zero');
    loders[val].setAttribute('onclick', `hideFn(${val})`);
  } else {
    ele.style.height = '0px';
    loders[val].setAttribute('onclick', `showFn(${val})`);
  }
});

function showFn(index) {
  accHtml.forEach((ele, val) => {
    if (index === val) {
      ele.style.height = fixedHeight + 'px';
      lodersImg[val].classList.add('rotate-zero');
      loders[val].setAttribute('onclick', `hideFn(${val})`);
    } else {
      ele.style.height = '0px';
      lodersImg[val].classList.remove('rotate-zero');
      loders[val].setAttribute('onclick', `showFn(${val})`);
    }
  });
}

function hideFn(index) {
  accHtml[index].style.height = '0px';
  lodersImg[index].classList.remove('rotate-zero');
  loders[index].setAttribute('onclick', `showFn(${index})`);
}


/* Email Validation */
let myForm = document.getElementById('myForm');
let emailField = document.getElementById('mailfield');
let errMsgBox = document.querySelector('.error');
let isvalid = false;

myForm.addEventListener('submit', (e) => {
  e.preventDefault();
  errMsgBox.innerText = '';
  let value = emailField.value.trim();
  let regx = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (value === '') {
    errMsgBox.innerText = '*This is a required field';
    emailField.focus();
  } else if (!regx.test(value)) {
    errMsgBox.innerText = '*invalid email address';
    emailField.focus();
  } else {
    errMsgBox.innerText = '';
    emailField.value = '';
    isvalid = true;
    alert("form submitted.");
  }

  return isvalid;
});


/* Hover Part for Service List */
let serviceList = document.querySelectorAll('.link');

serviceList.forEach((ele) => {
  ele.addEventListener('mouseenter', (e) => {
    console.log('Mouse entered the element!');
    e.currentTarget.children[0].setAttribute('src', 'images/arrow_white.png');
    e.currentTarget.children[0].style.color = "#fff";
  });

  ele.addEventListener('mouseleave', (e) => {
    console.log('Mouse left the element!');
    e.currentTarget.children[0].setAttribute('src', 'images/arrow_green.png');
  });
});
