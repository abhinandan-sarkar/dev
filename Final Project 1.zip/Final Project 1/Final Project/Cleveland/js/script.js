function queryAll(sel) {
  return document.querySelectorAll(sel);
}
function query(sel) {
  return document.querySelector(sel);
}
const eachElement = (list, cb) => list.forEach(cb);

let bannerImg = queryAll(".banner-img img");
let bannerText = queryAll(".banner-text");
let indicatorParent = query(".banner-indicator");
let sliderArea = query(".banner");

let totalSlides = bannerImg.length;
let currentSlide = 0;
let autoSlideInterval;
let fadeOutTimer;

// === Generate Dot Indicators
let indicatorHtml = "";
for (let i = 0; i < totalSlides; i++) {
  indicatorHtml += `<div class="indicator" onclick="onIndicatorClick(${i})"></div>`;
}
indicatorParent.innerHTML = indicatorHtml;
let indicators = queryAll(".indicator");

// === Fade Utility Functions
function fadeIn(el, duration = 600) {
  el.style.opacity = 0;
  el.style.visibility = "visible";
  el.style.transition = `opacity ${duration}ms ease-in`;
  requestAnimationFrame(() => {
    el.style.opacity = 1;
  });
}

function fadeOut(el, duration = 600) {
  el.style.transition = `opacity ${duration}ms ease-out`;
  el.style.opacity = 0;
  setTimeout(() => {
    el.style.visibility = "hidden";
  }, duration);
}

// === Show Image
function showOneImg(list, index) {
  eachElement(list, (el, i) => {
    if (i === index) {
      fadeIn(el);
    } else {
      fadeOut(el);
    }
  });
}

// === Show Text with Slide Animation
function showOneText(list, index) {
  eachElement(list, (el, i) => {
    el.classList.remove("active-slide");
    if (i === index) {
      void el.offsetWidth; // force reflow
      el.classList.add("active-slide");
    }
  });
}

// === Update Dots
function updateActiveIndicator(index) {
  eachElement(indicators, (el, i) => {
    el.classList.toggle("indicatorActive", i === index);
  });
}

// === Display Slide
function displaySlide(index) {
  currentSlide = index;
  showOneImg(bannerImg, index);
  showOneText(bannerText, index);
  updateActiveIndicator(index);
  scheduleFadeOut();
}

// === Dot Click
function onIndicatorClick(index) {
  displaySlide(index);
  restartAutoSlide();
}

// === Auto Slide Logic
function goToNextSlide() {
  currentSlide = (currentSlide + 1) % totalSlides;
  displaySlide(currentSlide);
}
function startAutoSlide() {
  autoSlideInterval = setInterval(goToNextSlide, 3000); // 3s delay
}
function stopAutoSlide() {
  clearInterval(autoSlideInterval);
}
function restartAutoSlide() {
  stopAutoSlide();
  startAutoSlide();
}

// === Schedule Auto Fade Out (Before next comes in)
function scheduleFadeOut() {
  clearTimeout(fadeOutTimer);
  fadeOutTimer = setTimeout(() => {
    fadeOut(bannerImg[currentSlide]);
    bannerText[currentSlide].classList.remove("active-slide");
  }, 2800); // fade before next appears
}

// === Pause on Hover
sliderArea.addEventListener("mouseenter", () => {
  stopAutoSlide();
  clearTimeout(fadeOutTimer);
});
sliderArea.addEventListener("mouseleave", () => {
  restartAutoSlide();
  scheduleFadeOut();
});

// === Init
displaySlide(currentSlide);
startAutoSlide();
