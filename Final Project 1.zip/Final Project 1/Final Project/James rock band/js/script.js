// ======= Utilities =======
function query(selector) {
  return document.querySelector(selector);
}
function queryAll(selector) {
  return document.querySelectorAll(selector);
}

// ======= DOM References =======
const tabMenu = queryAll('.menu');
const imageContainer = queryAll('.images-container');
const tab = queryAll('.tab');
const NRI = queryAll('.news-holder');
const bigImg = queryAll('.large-screen img');
const smallImg = queryAll('.poster-card img');
const viewBox = query('.view-holder');
const updateBox = query('.update-wrapper');
const featureBox = query('.features-wrapper');
let myIndex=0;

// ========= Initial Setup =========
/* show the tab menu logic */
for(let i=0;i<tabMenu.length;i++){
tabMenu[i].setAttribute('onclick',`showMenuContent(${i})`);
if(i==myIndex){
imageContainer[i].style.display="flex";
}else{
imageContainer[i].style.display="none";
}
}
/* show the tab  logic */
for(let i=0;i<NRI.length;i++){
tab[i].setAttribute('onclick',`showTabContent(${i})`);
if(i==myIndex){
NRI[i].style.display="block";
}else{
NRI[i].style.display="none";
}
}
// ======= Equalize Heights =======
const maxHeight = Math.max(
  viewBox.clientHeight,
  updateBox.clientHeight,
  featureBox.clientHeight
);
viewBox.style.height = updateBox.style.height = featureBox.style.height = maxHeight + 'px';

// ======= Image Switcher =======
function switchImage(images, activeIndex, className = "show") {
  images.forEach((img, i) => {
    img.classList.toggle(className, i === activeIndex);
  });
}

// ======= Show Tab Menu (Category) =======
function showMenuContent(index){
myIndex=index
for(let i=0;i<tabMenu.length;i++){
tabMenu[i].classList.remove('activeTabMenu');
if(i==myIndex){
imageContainer[i].style.display="flex";
tabMenu[i].classList.add('activeTabMenu');

}else{
tabMenu[i].classList.remove('activeTabMenu');
imageContainer[i].style.display="none";
}
}
}
// ======= Show Tab (News, Reviews, Interviews) =======

function showTabContent(index){
myIndex=index
for(let i=0;i<tabMenu.length;i++){
console.log(i);
if(i!=myIndex){
if(NRI[i]==undefined){ continue}
NRI[i].style.display="none";
tab[i].classList.remove('activeTab');
}else{
NRI[i].style.display="block";
tab[i].classList.add('activeTab');
}
}
}

// ======= Event Bindings =======
smallImg.forEach((img, i) => {
  img.addEventListener('click', () => switchImage(bigImg, i));
});

// ======= Initial Setup =======
switchImage(bigImg, 0, "show");
