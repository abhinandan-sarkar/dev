    // Slider DOM Elements
    var mainSlider = document.getElementById("mainSlider");
    var sliderContainer = document.getElementById("sliderContainer");
    var slides = document.getElementsByClassName("slide");
    var indicatorHolder = document.getElementById("indicatorHolder");

    // Slider Setup Variables
    var totalSlides = slides.length;
    var slideWidth = 1000;
    var slideGap = 4;
    var slideIntervalTime = 5000; // milliseconds
    var transitionDuration = 1200; // milliseconds

    // Active Slide Index Tracking
    var currentSlideIndex = 1;
    var currentIndicatorIndex = 1;
    var previousSlideIndex = 0;
    var nextSlideIndex = 2;
    var aminateSlide;
    var insInterval;
    // Display States
    var DISPLAY_ON = "inline-flex";
    var DISPLAY_OFF = "none";

    // Slide HTML for Cloning
    var originalSlideHTML = sliderContainer.innerHTML;
    var firstSlideHTML = slides[0].innerHTML;
    var duplicatedFirstSlide = '<div class="slide" id="slide' + (slides.length + 1) + '">' + firstSlideHTML + '</div>';
    sliderContainer.innerHTML = originalSlideHTML + duplicatedFirstSlide;

    // Generate Indicator HTML
    var indicatorHTMLStart = '<div class="indicators" onclick="goToSlide(';
    var indicatorHTMLEnd = ')"></div>';
    var indicatorsHTML = "";
    for (let i = 0; i < totalSlides; i++) {
      indicatorsHTML += indicatorHTMLStart + i + indicatorHTMLEnd;
    }
    indicatorHolder.innerHTML = indicatorsHTML;

    // Set Active Indicator
    var indicators = document.getElementsByClassName("indicators");
    indicators[0].classList.add("activeSlide");

    // Get Updated Slide Collection
    var allSlides = document.getElementsByClassName("slide");
    sliderContainer.style.width = ((slideWidth * allSlides.length) + (slideGap * (allSlides.length - 1))) + "px";

    // Set Transition for Indicators
    for (let i = 0; i < indicators.length; i++) {
      indicators[i].style.transition = (transitionDuration / 1000) + "s";
    }

    // Hide All Slides Initially
    for (let i = 0; i < slides.length; i++) {
      slides[i].style.display = DISPLAY_OFF;
    }

    // Show First Two Slides for Initial Load
    slides[0].style.display = DISPLAY_ON;
    slides[1].style.display = DISPLAY_ON;

    // Timer Variables
    var autoSlideTimer = setInterval(aminateSlideSlow, slideIntervalTime);
    var indicatorTimer = setInterval(updateIndicators, slideIntervalTime);
    var errorTimeout;

    // Function: Goto Slide By Indicator Click
    function goToSlide(index) {
      sliderContainer.style.transition = transitionDuration + "ms";

      clearInterval(autoSlideTimer);
      clearInterval(indicatorTimer);
      clearTimeout(errorTimeout);

      if (previousSlideIndex == index) {
        console.log("Same INDEX");
        slides[index + 1].style.display = DISPLAY_ON;
      } else if (index > previousSlideIndex) {
        for (let i = 0; i < slides.length; i++) {
          slides[i].style.display = DISPLAY_OFF;
        }
        slides[index].style.display = DISPLAY_ON;
        slides[previousSlideIndex].style.display = DISPLAY_ON;

        for (let i = 0; i < indicators.length; i++) {
          indicators[i].classList.remove("activeSlide");
        }
        indicators[index].classList.add("activeSlide");

        sliderContainer.style.transform = "translateX(-" + 1004 + "px)";
        currentIndicatorIndex = index + 1;

        setTimeout(function () {
          sliderContainer.style.transition = "0s";
          sliderContainer.style.transform = "translateX(0px)";
          slides[previousSlideIndex].style.display = DISPLAY_OFF;
          slides[index - 1].style.display = DISPLAY_OFF;
          slides[index + 1].style.display = DISPLAY_ON;
          previousSlideIndex = index;
          nextSlideIndex = (index == slides.length - 1) ? 0 : index + 2;
        }, transitionDuration);

        console.log("Higher INDEX");
      } else if (index < previousSlideIndex) {
        for (let i = 0; i < indicators.length; i++) {
          for (let j = 0; j < slides.length; j++) {
            slides[j].style.display = DISPLAY_OFF;
          }
          slides[previousSlideIndex + 1].style.display = DISPLAY_ON;
          slides[previousSlideIndex].style.display = DISPLAY_ON;
          indicators[i].classList.remove("activeSlide");
        }
        indicators[index].classList.add("activeSlide");

        let clonedHTML = allSlides[index].outerHTML;
        allSlides[previousSlideIndex + 1].outerHTML = clonedHTML;
        allSlides[previousSlideIndex + 1].style.display = DISPLAY_ON;
        sliderContainer.style.transform = "translateX(-" + 1004 + "px)";

        currentIndicatorIndex = index + 1;
        setTimeout(function () {
          sliderContainer.innerHTML = originalSlideHTML + duplicatedFirstSlide;
          for (let i = 0; i < slides.length; i++) {
            slides[i].style.display = DISPLAY_OFF;
          }
          slides[index].style.display = DISPLAY_ON;
          slides[previousSlideIndex].style.display = DISPLAY_ON;
          sliderContainer.style.transition = "0s";
          sliderContainer.style.transform = "translateX(0px)";
          previousSlideIndex = index;
          nextSlideIndex = (index == slides.length - 1) ? 0 : index + 2;
        }, transitionDuration);

        console.log("Lower INDEX");
      }
    }

    // Function: Autoplay Slide Animation
    function aminateSlideSlow() {
      sliderContainer.style.transition = transitionDuration + "ms";
      sliderContainer.style.transform = "translateX(-1004px)";

      console.log("slide changed " + (previousSlideIndex + 1) + " to " + (previousSlideIndex + 2));

      errorTimeout = setTimeout(() => {
        if (nextSlideIndex == allSlides.length) {
          nextSlideIndex = 0;
          sliderContainer.style.transform = "translateX(0px)";
          slides[previousSlideIndex].style.display = DISPLAY_OFF;
          previousSlideIndex = 0;
          sliderContainer.style.transition = "0s";
          sliderContainer.style.transform = "translateX(0px)";
          slides[nextSlideIndex].style.display = DISPLAY_ON;
          slides[totalSlides].style.display = DISPLAY_OFF;
          nextSlideIndex++;
          slides[nextSlideIndex++].style.display = DISPLAY_ON;
        } else {
          sliderContainer.style.transform = "translateX(0px)";
          slides[previousSlideIndex].style.display = DISPLAY_OFF;
          previousSlideIndex++;
          sliderContainer.style.transition = "0s";
          sliderContainer.style.transform = "translateX(0px)";
          slides[nextSlideIndex].style.display = DISPLAY_ON;
          nextSlideIndex++;
        }
      }, transitionDuration);
    }

    // Function: Change Indicator Automatically
    function updateIndicators() {
      for (let i = 0; i < indicators.length; i++) {
        indicators[i].classList.remove("activeSlide");
      }
      if (currentIndicatorIndex == totalSlides) {
        currentIndicatorIndex = 0;
      }
      indicators[currentIndicatorIndex].classList.add("activeSlide");
      currentIndicatorIndex++;
    }

    // Pause Autoplay on Hover
    mainSlider.addEventListener("mouseenter", function () {
      clearInterval(aminateSlide);
      clearInterval(insInterval);
      console.log("Mouse on the Slider Element");
    });

    // Resume Autoplay on Mouse Leave
    mainSlider.addEventListener("mouseleave", function () {
      aminateSlide = setInterval(aminateSlideSlow, slideIntervalTime);
      insInterval = setInterval(updateIndicators, slideIntervalTime);
      console.log("Mouse is out of the Slider Element");
    });